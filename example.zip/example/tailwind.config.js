module.exports = {
  content: ['./public/**/*.{html,js}'],
  theme: {
    extend: {
      fontFamily: {
        body: ['IBM Plex Mono'],
        body2:['VT323'],
     },
    },
  },
  plugins: [],
}
